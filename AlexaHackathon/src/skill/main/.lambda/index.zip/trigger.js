exports.whatAmIAllergicTo = (ingredients, allergies) => {
    return ingredients.reduce((filtered, val, idx, array) => {
        val = val.toLowerCase;
        if(allergies.indexOf(val) !== -1) {
            return filtered.push(val)
        }
    }, []);
};

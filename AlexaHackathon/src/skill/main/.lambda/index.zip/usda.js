const request = require('request');
const Promise = require('es6-promise').Promise;

const API_KEY = 'T2xKo1158ZtXaoKW2LOAJMbbjLgHgbjVS8nfH7fD';

exports.getFood = (query) => {
    return new Promise((resolve, reject) => {
        _getNDBNO(query).then((foodItemParams) => {
            return _getIngredients(foodItemParams);
        }).then((res) => {
            resolve(res);
        }).catch((reason) => {
            reject(reason);
        });
    });
};

const _getNDBNO = (query) => {
    return new Promise((resolve, reject) => {
        const url = 'http://api.nal.usda.gov/ndb/search/?type=b&format=json&api_key=' + API_KEY;
        const form ={
            api_key: API_KEY,
            q: query,
            max: '25',
            offset: '0',
            sort: 'r'
        };
        request.post({url: url, form: form}, (error, httpResponse, body) => {
            if(err) reject(err);
            else {
                var item = _getMostRelNDBNO(body)
                resolve({name: item.name, ndbno: item.ndbno.toString()});
            }
        });
    });
};

const _getMostRelNDBNO = (body) => {
    let foodItems = JSON.parse(body);
    foodItems = foodItems.list.item.filter((val, idx, arr) => {
        val.ds === 'BL'
    });
    return foodItems[0];
};

const _cleanIngredients = (ingredientString) => {
    return ingredientString.split(',').split('(').split(')').split('[').split(']').trim();
};

const _getIngredients = (foodItemParams) => {
    return new Promise((resolve, reject) {
        const url = 'https://api.nal.usda.gov/ndb/V2/reports?ndbno=' +
            foodItemParams.ndbno +
            '&type=b&format=json&api_key=' + API_KEY;
        const form ={
            api_key: api_key,
            max: '25',
            offset: '0'
        };
        request.post({url: url, form: form}, (error, httpResponse, body) => {
            if(err) reject(err);
            else {
                var report = JSON.parse(body);
                var ingredients = _cleanIngredients(report.foods[0].food.ing.desc);
                resolve({name: foodItemParams.name, ingredients: });
            }
        });
    });
};
